from tkinter import *
from tkinter import ttk
from PIL import Image,ImageTk
from termcolor import colored
from tkinter import messagebox
import mysql.connector


def main():
    win=Tk()
    app=Login_Window(win)
    win.mainloop()






class Login_Window:
    def __init__(self,root):
        self.root=root
        self.root.title("Login")
        self.root.geometry("1400x650+0+0")


        self.bg_image=ImageTk.PhotoImage(file=r"C:\Users\ABC\PycharmProjects\HotelManagementSystem\images\sd.JPEG")
        lbl_bg = Label(self.root, image=self.bg_image, bd=4, relief=RIDGE)
        lbl_bg.place(x=0, y=0,relwidth=1,relheight=1)#relwid-can adjust photo according to it

        frame=Frame(self.root,bg="#0F52BA")
        frame.place(x=500,y=100,width=360,height=470)

        Img1=Image.open(r"C:\Users\ABC\PycharmProjects\HotelManagementSystem\images\hotel images\redd.png")
        Img1=Img1.resize((100,100),Image.Resampling.LANCZOS)
        self.photo=ImageTk.PhotoImage(Img1)
        lblimag1=Label(image=self.photo,bg="#0F52BA",borderwidth=0)
        lblimag1.place(x=630,y=105,width=100,height=100)

        get_str=Label(frame,text="Login Page",font=("times new roman",20,"bold"),fg="white",bg="#0F52BA")
        get_str.place(x=120,y=100)

        #labels 1
        usernm_lbl=Label(frame,text="Username",font=("times new roman",20,"bold"),fg="white",bg="#0F52BA")
        usernm_lbl.place(x=80,y=155)

        self.t_entry=ttk.Entry(frame,font=("times new roman",20,"bold"))
        self.t_entry.place(x=40,y=190,width=280)

        passwrd_lbl = Label(frame, text="Password", font=("times new roman", 20, "bold"), fg="white", bg="#0F52BA")
        passwrd_lbl.place(x=80, y=250)

        self.p_entry = ttk.Entry(frame, font=("times new roman", 20, "bold"),show='*')
        self.p_entry.place(x=40, y=285, width=280)

        #============== icon image========================
        Img2 = Image.open( r"C:\Users\ABC\PycharmProjects\HotelManagementSystem\images\hotel images\LoginIconAppl.png")
        Img2 = Img2.resize((25, 25), Image.Resampling.LANCZOS)
        self.photo1 = ImageTk.PhotoImage(Img2)
        lblimag2 = Label(image=self.photo1, bg="#0F52BA", borderwidth=0)
        lblimag2.place(x=540, y=260, width=25, height=25)

        Img3 = Image.open(r"C:\Users\ABC\PycharmProjects\HotelManagementSystem\images\hotel images\lock-512.png")
        Img3 = Img3.resize((25, 25), Image.Resampling.LANCZOS)
        self.photo2 = ImageTk.PhotoImage(Img3)
        lblimag3 = Label(image=self.photo2, bg="#0F52BA", borderwidth=0)
        lblimag3.place(x=540, y=355, width=25, height=25)

        # login button
        login_btn=Button(frame,text='Login',command=self.login,font=("times new roman", 20, "bold"),bd=1,relief=RAISED,bg='#0F52BA',fg='white',
                         activeforeground='white',activebackground='black')
        #fg=text color,activeforeground='white',activebackground='black'=can set color while click on it
        login_btn.place(x=110,y=350,width=120,height=35)

        # register button
        register_btn = Button(frame, command=self.register_window,text='New User Register', font=("times new roman", 10, "bold"),borderwidth=0, bg='#0F52BA',fg='white',
                           activeforeground='white', activebackground='black')
        register_btn.place(x=10, y=400, width=110)

        # forget password button
        forget_btn = Button(frame, command=self.forget_passward,text='Forget Password', font=("times new roman",10, "bold"),borderwidth=0, bg='#0F52BA',fg='white',
                           activeforeground='white', activebackground='black')
        forget_btn.place(x=10, y=420, width=110)


    def register_window(self):
        self.new_window=Toplevel(self.root)
        self.app=Register(self.new_window)


    def login(self):
        if self.t_entry.get()=="" or self.p_entry.get()=="":
            messagebox.showerror("Error",'All field required')
        elif self.t_entry.get()=='vin' and self.p_entry.get()=='vin':
            messagebox.showinfo("Congrats","Welcome at my page❤")
        else:
             connection = mysql.connector.connect(host="localhost", user="root", password="W7301@jqir*", database="sql_workbench")
             my_cursor = connection.cursor()
             my_cursor.execute("select * from login where email=%s and password=%s",(
                 self.t_entry.get(),
                 self.p_entry.get() ))
             row=my_cursor.fetchone()
             if row==None:
                 messagebox.showerror("eeeError", "Invalid username and password")
             else:
                 open_main = messagebox.askyesno("YesNo", "Access only admin")
                 if open_main > 0:
                     self.new_window = Toplevel(self.root)
                     self.app = HMS(self.new_window)
                 else:
                     if not open_main:
                         return
             connection.commit()
             connection.close()


#=====================reset pasword=================================
    def reset_password(self):
        if self.combo.get()=="Select":
            messagebox.showerror("Error","Select security question??",parent=self.root2)
        elif self.securtyA_entry.get()=="":
            messagebox.showerror("Error","Kindly,enter security answer",parent=self.root2)
        elif self.new_pswrd_entry.get()=="":
            messagebox.showerror("Error","kindly,enter new password",parent=self.root2)
        else:
            connection = mysql.connector.connect(host="localhost", user="root", password="W7301@jqir*",
                                                 database="sql_workbench")
            my_cursor = connection.cursor()
            query=("select * from login where email=%s and securityQ=%s and securityA=%s")
            value=(self.t_entry.get(),self.combo.get(),self.securtyA_entry.get())
            my_cursor.execute(query,value)
            row=my_cursor.fetchone()
            if row==None:
                messagebox.showerror("Error","Kindly,enter correct security answer",parent=self.root2)

            else:
                query2=("update login set password=%s where email=%s")
                value2=(self.new_pswrd_entry.get(),self.t_entry.get())
                my_cursor.execute(query2,value2)

                connection.commit()
                connection.close()
                messagebox.showinfo("Congrats💖","your password has been reset,login new password",parent=self.root2)
                self.root2.destroy()


 #====================================== forget button function====================================

    def forget_passward(self):
        if self.t_entry.get()=="":
            messagebox.showerror("Error","kindly,enter email address first",parent=self.root)

        else:
             connection = mysql.connector.connect(host="localhost", user="root", password="W7301@jqir*", database="sql_workbench")
             my_cursor = connection.cursor()
             query=("select * from login where email=%s")
             value=(self.t_entry.get(),)
             my_cursor.execute(query,value)
             row=my_cursor.fetchone()
             #print(row) show output in console window

             if row==None:
                 messagebox.showerror("Error","Kindly,enter valid username")
             else:
                 connection.close()
                 self.root2=Toplevel()
                 self.root2.title("FORGET PASSWORD")
                 self.root2.geometry("400x450+500+120")

                 lbl=Label(self.root2,text="Forget Password",font=("times new roman", 20, "bold"),bd=1,relief=RAISED,bg='#0F52BA',fg='white')
                 lbl.place(x=0,y=10,relwidth=1)

                 # =========================== row-3
                 securtyQ_nm = Label(self.root2, text="Select Security Question", font=("times new roman", 15, "bold"),
                                     bg="#87CEEB")
                 securtyQ_nm.place(x=80, y=80)

                 self.combo = ttk.Combobox(self.root2,font=("times new roman", 15, "bold"))
                 self.combo["values"] = ("Select", "Your Birth Place", "Your Favourite Color", "Your Favourite Book")
                 self.combo.place(x=80, y=110, width=250)
                 self.combo.current(0)

                 securtyA_nm = Label(self.root2, text="Security Answer ", font=("times new roman", 15, "bold"), bg="#87CEEB")
                 securtyA_nm.place(x=80, y=160)

                 self.securtyA_entry = ttk.Entry(self.root2,font=("times new roman", 15, "bold"))
                 self.securtyA_entry.place(x=80, y=190, width=250)

                 # =========================== row-4
                 new_pswrd_nm = Label(self.root2, text="New Password", font=("times new roman", 15, "bold"), bg="#87CEEB")
                 new_pswrd_nm.place(x=80, y=240)

                 self.new_pswrd_entry = ttk.Entry(self.root2, font=("times new roman", 15, "bold"))
                 self.new_pswrd_entry.place(x=80, y=270, width=250)

                 btn=Button(self.root2,text="Reset",command=self.reset_password,font=("times new roman", 15, "bold"), bg="#87CEEB")
                 btn.place(x=120,y=320,width=100)







#===================================================== new class name= register=========================================

class Register:
    def __init__(self,root):
        self.root=root
        self.root.title("Register")
        self.root.geometry("1500x650+0+0")

        #============================= variable==========================
        self.var_fname=StringVar()
        self.var_Lname=StringVar()
        self.var_contact = StringVar()
        self.var_email = StringVar()
        self.var_sequrtyQ = StringVar()
        self.var_sequrtyA = StringVar()
        self.var_paswrd = StringVar()
        self.var_cnfrm_pswrd = StringVar()
        self.var_check=IntVar()

        #==================bg image====================
        self.bg=ImageTk.PhotoImage(file=r"C:\Users\ABC\PycharmProjects\HotelManagementSystem\images\image.WEBP")
        bg_lbl=Label(self.root,image=self.bg)
        bg_lbl.place(x=0,y=0,relwidth=1,relheight=1)

        # ==================left image====================
        self.bg1 = ImageTk.PhotoImage(file=r"C:\Users\ABC\PycharmProjects\HotelManagementSystem\images\img.jpg")
        left_lbl = Label(self.root, image=self.bg1)
        left_lbl.place(x=50, y=100,width=400, height=480)

        # =====================main frame==================
        frame=Frame(self.root,bg='#87CEEB')
        frame.place(x=450,y=100,width=700,height=480)

        register_lbl=Label(frame,text="REGISTER HERE",font=('times new roman',18,'bold'),fg='#008080',bg='#87CEEB')
        #fg- font color
        register_lbl.place(x=20,y=20)

        #================= labels and entry fills=====================

        #============================= row-1
        fst_nm = Label(frame, text="First Name", font=("times new roman", 15, "bold"),bg="#87CEEB")
        fst_nm.place(x=50, y=80)

        self.fst_entry = ttk.Entry(frame,textvariable=self.var_fname, font=("times new roman",15, "bold"))
        self.fst_entry.place(x=50, y=110, width=250)

        last_nm = Label(frame, text="Last Name", font=("times new roman",15, "bold"),bg="#87CEEB")
        last_nm.place(x=350, y=80)

        self.last_entry = ttk.Entry(frame,textvariable=self.var_Lname ,font=("times new roman",15, "bold"))
        self.last_entry.place(x=350, y=110, width=250)

        #=========================== row-2
        contct_nm = Label(frame, text="Contact No", font=("times new roman", 15, "bold"), bg="#87CEEB")
        contct_nm.place(x=50, y=150)

        self.contact_entry = ttk.Entry(frame,textvariable=self.var_contact ,font=("times new roman", 15, "bold"))
        self.contact_entry.place(x=50, y=180, width=250)

        email = Label(frame, text="Email ", font=("times new roman", 15, "bold"), bg="#87CEEB")
        email.place(x=350, y=150)

        self.email_entry = ttk.Entry(frame, textvariable=self.var_email,font=("times new roman",15, "bold"))
        self.email_entry.place(x=350, y=180, width=250)

        # =========================== row-3
        securtyQ_nm = Label(frame, text="Select Security Question", font=("times new roman", 15, "bold"), bg="#87CEEB")
        securtyQ_nm.place(x=50, y=210)

        self.combo=ttk.Combobox(frame,textvariable=self.var_sequrtyQ,font=("times new roman",15, "bold"))
        self.combo["values"]=("Select","Your Birth Place","Your Favourite Color","Your Favourite Book")
        self.combo.place(x=50,y=240,width=250)
        self.combo.current(0)

        securtyA_nm = Label(frame, text="Security Answer ", font=("times new roman", 15, "bold"), bg="#87CEEB")
        securtyA_nm.place(x=350, y=210)

        self.securtyA_entry = ttk.Entry(frame,textvariable=self.var_sequrtyA ,font=("times new roman", 15, "bold"))
        self.securtyA_entry.place(x=350, y=240, width=250)

        # =========================== row-4
        pswrd_nm = Label(frame, text="Password", font=("times new roman", 15, "bold"), bg="#87CEEB")
        pswrd_nm.place(x=50, y=280)

        self.pswrd_entry = ttk.Entry(frame, textvariable=self.var_paswrd,font=("times new roman", 15, "bold"))
        self.pswrd_entry.place(x=50, y=310, width=250)

        cnfrm_pass = Label(frame, text="Confirm password", font=("times new roman", 15, "bold"), bg="#87CEEB")
        cnfrm_pass.place(x=350, y=280)

        self.cnfrm_pass_entry = ttk.Entry(frame,textvariable=self.var_cnfrm_pswrd, font=("times new roman", 15, "bold"))
        self.cnfrm_pass_entry.place(x=350, y=310, width=250)

        #========================== check button====================
        check_btn=Checkbutton(frame,variable=self.var_check,text="I Agree With The Terms & Conditions",font=("Cursive", 12, "bold")
                              ,onvalue=1,offvalue=0,bg='#87CEEB',activebackground='#87CEEB')
        check_btn.place(x=50,y=350)

        #========================button===============================
        img=Image.open(r"C:\Users\ABC\PycharmProjects\HotelManagementSystem\images\hotel images\register-now-button1.jpg")

        # img=img.resize(200,50)
        ''' Unknown resampling filter (50). Use Image.Resampling.NEAREST (0), Image.Resampling.LANCZOS (1), 
        Image.Resampling.BILINEAR (2),
        Image.Resampling.BICUBIC (3), 
        Image.Resampling.BOX (4) or
        Image.Resampling.HAMMING (5) '''

        img = img.resize((150, 50),Image.Resampling.LANCZOS )
        self.photo=ImageTk.PhotoImage(img)
        b1=Button(frame,command=self.register_data,image=self.photo,borderwidth=0,cursor="hand2",font=("times new roman", 15, "bold"),bg='#87CEEB',activebackground='#87CEEB')
        b1.place(x=50,y=400,width=150,height=44)

        img2 = Image.open(r"C:\Users\ABC\PycharmProjects\HotelManagementSystem\images\hotel images\login.jpg")
        img2 = img2.resize((180, 50), Image.Resampling.LANCZOS)
        self.photo2 = ImageTk.PhotoImage(img2)
        b2 = Button(frame,command=self.back_to_login, image=self.photo2, borderwidth=0, cursor="hand2", font=("times new roman", 15, "bold"),bg='#87CEEB',activebackground='#87CEEB')
        b2.place(x=330, y=400, width=180,height=40)

     #================================= function decleration========================
    def register_data(self):
        if self.var_fname.get()=="" or self.var_email.get()=="" or self.var_sequrtyQ.get()=="Select":
            messagebox.showerror("Error","All fields are required !!",parent=self.root)
        elif self.var_paswrd.get()!=self.var_cnfrm_pswrd.get():
            messagebox.showerror("Error","Confirm password must be same as password",parent=self.root)
        elif self.var_check.get()==0:
            messagebox.showerror("Error","Kindly, tick on terms & condition",parent=self.root)
        else:
            connection = mysql.connector.connect(host="localhost", user="root", password="W7301@jqir*",
                                           database="sql_workbench")
            my_cursor = connection.cursor()
            query=("select * from login where email=%s")
            value=(self.var_email.get(),)
            my_cursor.execute(query,value)
            # now fetching data from mysql
            row=my_cursor.fetchone()
            if row!=None:
                messagebox.showerror("Error","User alreadt exist,try another email😢",parent=self.root)
            else:
                my_cursor.execute("insert into login values(%s,%s,%s,%s,%s,%s,%s)",(
                # getting all values from entry variable and inserting into database
                self.var_fname.get(),
                self.var_Lname.get(),
                self.var_contact.get(),
                self.var_email.get(),
                self.var_sequrtyQ.get(),
                self.var_sequrtyA.get(),
                self.var_paswrd.get()  ))
            connection.commit()
            connection.close()
            messagebox.showinfo("Congrats💖","Register Successfully❤",parent=self.root)

    def back_to_login(self):
        self.root.destroy()







# 3rd class hotel management system
class HMS:
    def __init__(self,root):
        self.root=root
        self.root.title("Hotel Management System ")
        self.root.geometry("1270x640+5+10")

        #============================ 1st image===========================
        #Img1=Image.open("C:\\Users\\ABC\\PycharmProjects\\HotelManagementSystem\hotel.png")
        Img1=Image.open(r"C:/Users/ABC/PycharmProjects/HotelManagementSystem/images/hotel images/hotel2.webp")
        #Img1=Image.open(r"C:\Users\ABC\PycharmProjects\HotelManagementSystem\1633410403702hotel-images\hotel images\bed.jpg")
        Img1=Img1.resize((1260,140),Image.BILINEAR)
        self.photoImg1=ImageTk.PhotoImage(Img1)

        lblimg=Label(self.root,image=self.photoImg1,bd=4,relief=RIDGE)
        lblimg.place(x=0,y=0,width=1270,height=140)


        #================= Logo =======================================
        Img2 = Image.open(r"C:\Users\ABC\PycharmProjects\HotelManagementSystem\images\hotel images\logohotel.png")
        Img2 = Img2.resize((230, 140), Image.BILINEAR)
        self.photoImg2 = ImageTk.PhotoImage(Img2)

        lblimg = Label(self.root, image=self.photoImg2, bd=4, relief=RIDGE)
        lblimg.place(x=0, y=0, width=230, height=140)

        lbl_title = Label(self.root,text="HOTEL MANAGEMENT SYSTEM",font=("times new roman",40,"bold"),bg="black",fg="gold",relief=RIDGE,bd=4)
        lbl_title.place(x=0,y=140,width=1540, height=50)

        #====================== Min frame ==========================
        main_frame=Frame(self.root,bd=5,relief="sunken")
        main_frame.place(x=0,y=190,width=1550,height=620)

        #========================Menu =============================
        lbl_menu = Label(main_frame, text="MENU", font=("times new roman", 20, "bold"), bg="black",fg="gold", relief=RIDGE, bd=4)
        lbl_menu.place(x=0, y=0, width=230)

        #======================== btn frame========================
        btn_frame = Frame(main_frame, bd=5, relief="sunken")
        btn_frame.place(x=0, y=35, width=228, height=190)

        cust_btn = Button(btn_frame, text="CUSTOMER",command=self.cust_details,width=22, font=("times new roman", 14, "bold"),bd=0, bg="black",fg="gold",cursor="hand1")
        cust_btn.grid(row=0, column=0,padx=1, pady=1,sticky=E)

        room_btn = Button(btn_frame,command=self.roombooking, text="ROOM", width=22, font=("times new roman", 14, "bold"), bd=0, bg="black",fg="gold",cursor="hand2")
        room_btn.grid(row=1, column=0,padx=1, pady=1)

        details_btn = Button(btn_frame, text="DETAILS",command=self.detailsroom ,width=22, font=("times new roman", 14, "bold"), bd=0, bg="black",fg="gold",cursor="hand2")
        details_btn.grid(row=2, column=0,padx=1, pady=1)

        report_btn = Button(btn_frame, text="REPORT", width=22, font=("times new roman", 14, "bold"), bd=0, bg="black",fg="gold",cursor="hand2")
        report_btn.grid(row=3, column=0,padx=1, pady=1)

        logout_btn = Button(btn_frame, text="LOGOUT", command=self.logout,width=22, font=("times new roman", 14, "bold"), bd=0, bg="black",fg="gold",cursor="hand2")
        logout_btn.grid(row=4, column=0,padx=1, pady=1)

        # ================= right side image =======================================
        Img3 = Image.open( r"C:\Users\ABC\PycharmProjects\HotelManagementSystem\images\hotel images\hotel3.webp")
        Img3 = Img3.resize((1050, 450), Image.BILINEAR)
        self.photoImg3 = ImageTk.PhotoImage(Img3)

        lblimg1 = Label(main_frame, image=self.photoImg3, bd=4, relief=RIDGE)
        lblimg1.place(x=225, y=0, width=1050, height=450)

        # ================= down image =======================================
        Img4 = Image.open(r"C:\Users\ABC\PycharmProjects\HotelManagementSystem\images\hotel images\myh.jpg")
        Img4 = Img4.resize((220, 200), Image.BILINEAR)
        self.photoImg4 = ImageTk.PhotoImage(Img4)

        lblimg2 = Label(main_frame, image=self.photoImg4, bd=4, relief=RIDGE)
        lblimg2.place(x=0, y=220, width=226, height=230)#h=outside image size,y=inside

        # Img5 = Image.open(r"C:\Users\ABC\PycharmProjects\HotelManagementSystem\1633410403702hotel-images\hotel images\khana.jpg")
        '''Img5 = Img5.resize((225, 190), Image.BILINEAR)
                self.photoImg5 = ImageTk.PhotoImage(Img5)

                lblimg3 = Label(main_frame, image=self.photoImg5, bd=4, relief=RIDGE)
                lblimg3.place(x=0, y=230, width=225, height=200)'''

    def cust_details(self):
        self.new_window=Toplevel(self.root)
        self.app=Cust_win(self.new_window)

    def roombooking(self):
        self.new_window=Toplevel(self.root)
        self.app=Room_booking(self.new_window)

    def detailsroom(self):
        self.new_window=Toplevel(self.root)
        self.app=DetailsRooms(self.new_window)

    def logout(self):
        self.root.destroy()




if __name__ == '__main__':
    main()

