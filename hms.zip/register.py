from tkinter import *
from tkinter import ttk
from PIL import Image,ImageTk
from termcolor import colored
from tkinter import messagebox
import mysql.connector


class Register:
    def __init__(self,root):
        self.root=root
        self.root.title("Register")
        self.root.geometry("1500x650+0+0")

        #============================= variable==========================
        self.var_fname=StringVar()
        self.var_Lname=StringVar()
        self.var_contact = StringVar()
        self.var_email = StringVar()
        self.var_sequrtyQ = StringVar()
        self.var_sequrtyA = StringVar()
        self.var_paswrd = StringVar()
        self.var_cnfrm_pswrd = StringVar()
        self.var_check=IntVar()

        #==================bg image====================
        self.bg=ImageTk.PhotoImage(file=r"C:\Users\ABC\PycharmProjects\HotelManagementSystem\images\image.WEBP")
        bg_lbl=Label(self.root,image=self.bg)
        bg_lbl.place(x=0,y=0,relwidth=1,relheight=1)

        # ==================left image====================
        self.bg1 = ImageTk.PhotoImage(file=r"C:\Users\ABC\PycharmProjects\HotelManagementSystem\images\img.jpg")
        left_lbl = Label(self.root, image=self.bg1)
        left_lbl.place(x=50, y=100,width=400, height=480)

        # =====================main frame==================
        frame=Frame(self.root,bg='#87CEEB')
        frame.place(x=450,y=100,width=700,height=480)

        register_lbl=Label(frame,text="REGISTER HERE",font=('times new roman',18,'bold'),fg='#008080',bg='#87CEEB')
        #fg- font color
        register_lbl.place(x=20,y=20)

        #================= labels and entry fills=====================

        #============================= row-1
        fst_nm = Label(frame, text="First Name", font=("times new roman", 15, "bold"),bg="#87CEEB")
        fst_nm.place(x=50, y=80)

        self.fst_entry = ttk.Entry(frame,textvariable=self.var_fname, font=("times new roman",15, "bold"))
        self.fst_entry.place(x=50, y=110, width=250)

        last_nm = Label(frame, text="Last Name", font=("times new roman",15, "bold"),bg="#87CEEB")
        last_nm.place(x=350, y=80)

        self.last_entry = ttk.Entry(frame,textvariable=self.var_Lname ,font=("times new roman",15, "bold"))
        self.last_entry.place(x=350, y=110, width=250)

        #=========================== row-2
        contct_nm = Label(frame, text="Contact No", font=("times new roman", 15, "bold"), bg="#87CEEB")
        contct_nm.place(x=50, y=150)

        self.contact_entry = ttk.Entry(frame,textvariable=self.var_contact ,font=("times new roman", 15, "bold"))
        self.contact_entry.place(x=50, y=180, width=250)

        email = Label(frame, text="Email ", font=("times new roman", 15, "bold"), bg="#87CEEB")
        email.place(x=350, y=150)

        self.email_entry = ttk.Entry(frame, textvariable=self.var_email,font=("times new roman",15, "bold"))
        self.email_entry.place(x=350, y=180, width=250)

        # =========================== row-3
        securtyQ_nm = Label(frame, text="Select Security Question", font=("times new roman", 15, "bold"), bg="#87CEEB")
        securtyQ_nm.place(x=50, y=210)

        self.combo=ttk.Combobox(frame,textvariable=self.var_sequrtyQ,font=("times new roman",15, "bold"))
        self.combo["values"]=("Select","Your Birth Place","Your Favourite Color","Your Favourite Book")
        self.combo.place(x=50,y=240,width=250)
        self.combo.current(0)

        securtyA_nm = Label(frame, text="Security Answer ", font=("times new roman", 15, "bold"), bg="#87CEEB")
        securtyA_nm.place(x=350, y=210)

        self.securtyA_entry = ttk.Entry(frame,textvariable=self.var_sequrtyA ,font=("times new roman", 15, "bold"))
        self.securtyA_entry.place(x=350, y=240, width=250)

        # =========================== row-4
        pswrd_nm = Label(frame, text="Password", font=("times new roman", 15, "bold"), bg="#87CEEB")
        pswrd_nm.place(x=50, y=280)

        self.pswrd_entry = ttk.Entry(frame, textvariable=self.var_paswrd,font=("times new roman", 15, "bold"))
        self.pswrd_entry.place(x=50, y=310, width=250)

        cnfrm_pass = Label(frame, text="Confirm password", font=("times new roman", 15, "bold"), bg="#87CEEB")
        cnfrm_pass.place(x=350, y=280)

        self.cnfrm_pass_entry = ttk.Entry(frame,textvariable=self.var_cnfrm_pswrd, font=("times new roman", 15, "bold"))
        self.cnfrm_pass_entry.place(x=350, y=310, width=250)

        #========================== check button====================
        check_btn=Checkbutton(frame,variable=self.var_check,text="I Agree With The Terms & Conditions",font=("Cursive", 12, "bold")
                              ,onvalue=1,offvalue=0,bg='#87CEEB',activebackground='#87CEEB')
        check_btn.place(x=50,y=350)

        #========================button===============================
        img=Image.open(r"C:\Users\ABC\PycharmProjects\HotelManagementSystem\images\hotel images\register-now-button1.jpg")

        # img=img.resize(200,50)
        ''' Unknown resampling filter (50). Use Image.Resampling.NEAREST (0), Image.Resampling.LANCZOS (1), 
        Image.Resampling.BILINEAR (2),
        Image.Resampling.BICUBIC (3), 
        Image.Resampling.BOX (4) or
        Image.Resampling.HAMMING (5) '''

        img = img.resize((150, 50),Image.Resampling.LANCZOS )
        self.photo=ImageTk.PhotoImage(img)
        b1=Button(frame,command=self.register_data,image=self.photo,borderwidth=0,cursor="hand2",font=("times new roman", 15, "bold"),bg='#87CEEB',activebackground='#87CEEB')
        b1.place(x=50,y=400,width=150,height=44)

        img2 = Image.open(r"C:\Users\ABC\PycharmProjects\HotelManagementSystem\images\hotel images\login.jpg")
        img2 = img2.resize((180, 50), Image.Resampling.LANCZOS)
        self.photo2 = ImageTk.PhotoImage(img2)
        b2 = Button(frame, image=self.photo2, borderwidth=0, cursor="hand2", font=("times new roman", 15, "bold"),bg='#87CEEB',activebackground='#87CEEB')
        b2.place(x=330, y=400, width=180,height=40)

     #================================= function decleration========================
    def register_data(self):
        if self.var_fname.get()=="" or self.var_email.get()=="" or self.var_sequrtyQ.get()=="Select":
            messagebox.showerror("Error","All fields are required !!",parent=self.root)
        elif self.var_paswrd.get()!=self.var_cnfrm_pswrd.get():
            messagebox.showerror("Error","Confirm password must be same as password",parent=self.root)
        elif self.var_check.get()==0:
            messagebox.showerror("Error","Kindly, tick on terms & condition",parent=self.root)
        else:
            connection = mysql.connector.connect(host="localhost", user="root", password="W7301@jqir*",
                                           database="sql_workbench")
            my_cursor = connection.cursor()
            query=("select * from login where email=%s")
            value=(self.var_email.get(),)
            my_cursor.execute(query,value)
            # now fetching data from mysql
            row=my_cursor.fetchone()
            if row!=None:
                messagebox.showerror("Error","User alreadt exist,try another email😢",parent=self.root)
            else:
                my_cursor.execute("insert into login values(%s,%s,%s,%s,%s,%s,%s)",(
                # getting all values from entry variable and inserting into database
                self.var_fname.get(),
                self.var_Lname.get(),
                self.var_contact.get(),
                self.var_email.get(),
                self.var_sequrtyQ.get(),
                self.var_sequrtyA.get(),
                self.var_paswrd.get()  ))
            connection.commit()
            connection.close()
            messagebox.showinfo("Congrats💖","Register Successfully❤",parent=self.root)


if __name__ == '__main__':
    root=Tk()
    app=Register(root)
    root.mainloop()
